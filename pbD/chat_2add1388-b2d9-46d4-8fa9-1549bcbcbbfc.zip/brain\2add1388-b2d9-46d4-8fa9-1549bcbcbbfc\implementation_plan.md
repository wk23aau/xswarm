# Antigravity API - Proper Implementation Plan

## Problem Statement

Current "API" is just UI automation - not a real API. Need a proper programmatic interface that:
- Sends to **specific conversations** (not just whatever is open)
- Works **without manual DevTools setup**
- Returns **AI responses** (not just fire-and-forget)

## What We Know

| ✅ Working | ❌ Blocked |
|-----------|-----------|
| Protobuf structure decoded | Direct HTTP fails (origin checks) |
| Server at 127.0.0.1:62774 reachable | CDP can't access webview |
| OAuth tokens captured | CSRF tied to session |

## Proposed Approaches

### Approach 1: gRPCurl/Protobuf with Captured Session

Since the Antigravity client CAN send messages, we can:
1. Capture the **exact request** including all headers
2. Replay it with a different message payload
3. Use the captured OAuth + CSRF tokens

> [!IMPORTANT]
> This requires capturing a fresh session each time Antigravity restarts.

**Files to create:**
- `antigravity_proto_api.py` - Uses captured tokens to send

---

### Approach 2: Browser-Mediated API (Enhanced Bridge)

Make the bridge smarter to be a proper API:
1. Auto-inject script on Antigravity load (VS Code extension)
2. Support **conversation switching** 
3. Return **AI responses** back to Python

**Files to create:**
- `bridge_client_v4.js` - With conversation control + response capture
- `antigravity_api_v2.py` - Full API with response handling

---

### Approach 3: VS Code Extension Approach

Build a VS Code extension that:
1. Has direct access to Antigravity's internal APIs
2. Exposes an HTTP/WebSocket server for external calls
3. Full control over conversations

**This is the most robust but complex approach.**

## Recommended: Approach 2 (Enhanced Bridge)

The quickest path to a "real API feel" is enhancing the bridge to:
1. **Switch conversations** by clicking history items
2. **Capture responses** by observing DOM changes
3. **Auto-inject** via a VS Code settings tweak

## Next Steps

1. Choose approach (1, 2, or 3)
2. Implement selected approach
3. Test with xswarm integration
