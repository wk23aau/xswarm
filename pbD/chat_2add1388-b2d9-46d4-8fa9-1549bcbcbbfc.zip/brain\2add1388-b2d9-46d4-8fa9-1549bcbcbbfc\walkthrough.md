# Antigravity API Research - Final Walkthrough

## Summary

Reverse-engineered Antigravity IDE's API. Successfully accessed session management and streaming endpoints. `SendUserCascadeMessage` blocked for external clients due to HTTP/2 session binding.

## Final Deliverable

All scripts consolidated in **`pbD/`** folder:

| File | Purpose |
|------|---------|
| [README.md](file:///c:/Users/wk23aau/Downloads/xspace/xswarm/pbD/README.md) | Complete documentation |
| [antigravity_api.py](file:///c:/Users/wk23aau/Downloads/xspace/xswarm/pbD/antigravity_api.py) | Python API client |
| [antigravity_bridge.py](file:///c:/Users/wk23aau/Downloads/xspace/xswarm/pbD/antigravity_bridge.py) | Bridge server |
| [bridge_client.js](file:///c:/Users/wk23aau/Downloads/xspace/xswarm/pbD/bridge_client.js) | UI automation script |
| [fetch_interceptor.js](file:///c:/Users/wk23aau/Downloads/xspace/xswarm/pbD/fetch_interceptor.js) | Request debug tool |
| [stream_interceptor.js](file:///c:/Users/wk23aau/Downloads/xspace/xswarm/pbD/stream_interceptor.js) | Response capture tool |

## Key Findings

| Finding | Status |
|---------|--------|
| `StartCascade` | ✅ Works from Python |
| `StreamCascadeReactiveUpdates` | ✅ Works from Python |
| `LogEvent` | ✅ Works from Python |
| `SendUserCascadeMessage` | ❌ Blocked (HTTP/2 session binding) |
| UI Simulation Bridge | ✅ Full access via DevTools |

## Root Cause Analysis

`SendUserCascadeMessage` fails for external clients because:
1. Antigravity uses internal gRPC-Web/Connect transport
2. HTTP/2 connections are session-bound to the Electron process
3. Even same-process `fetch()` calls get `ERR_HTTP2_PROTOCOL_ERROR`

## Solution: UI Simulation Bridge

The reliable workaround uses UI automation:
1. Run `python antigravity_bridge.py`
2. Paste `bridge_client.js` in DevTools
3. Send messages via `bridge.send("Hello!")`
